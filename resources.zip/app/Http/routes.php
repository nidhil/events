<?php

Route::get('/', function () {
    return view('Events.home');
});
Route::get('/u', 'EventController@upcomingEvent');
Route::get('search', 'SearchController@index');
Route::group(['middleware' => ['web']], function () {
    //Routes for the user controller
    Route::get('myorder', 'UserController@getOrders');
    Route::get('myevents', 'UserController@getEvents');
      //Route for event registrations
    Route::post('quantity', 'BookingController@getQuantity');
    //Route::get('register/checkout','BookingController@getCheckout');
    Route::post('checkout', 'BookingController@checkout');
    //routes for the event
    Route::post('eventup','EventController@newEvent');
    Route::get('event/category/{category}','EventController@getEventsCategory');
    Route::resource('event', 'EventController');
    });

Route::group(['middleware' => 'web'], function () {
    Route::auth();
    Route::get('/home', 'HomeController@index');
    Route::get('register/confirm/{token}', 'Auth\AuthController@confirmEmail');


});


Route::group(['middleware' => 'web'], function () {
    Route::auth();

    Route::get('/home', 'HomeController@index');
    Route::get('eventup', function(){
        return view('eventup');
    });
});
