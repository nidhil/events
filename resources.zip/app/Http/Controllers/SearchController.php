<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Event;
use Symfony\Component\HttpFoundation\Response;

class SearchController extends Controller
{
    public function index(Request $request){
        $location = $request->location;
        $event = $request->event;
        $events = Event::where('eventCategory', 'like', '%'.$event.'%')
                            ->where('eventLocation', 'like', '%'.$location.'%')
                            ->get(['eventLocation', 'eventName']);
        //$data = $result->toArray();
       // return response()->json($data);
        //dd(count($events));

        return view('Events.SearchResult',compact('events'));

    }
}
