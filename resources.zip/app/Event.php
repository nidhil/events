<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $fillable = [
        'eventName',
        'eventLocation',
        'eventStartTime',
        'eventEndTime',
        'eventStartDate',
        'eventEndDate',
        'eventDescription',
        'eventCategory',
        'eventPrice',
        'eventType',
        'eventTickets',


    ];

    protected $dates = [
        'eventStartDate',
        'eventEndDate',
    ];

    public function bookings(){
        return $this->hasMany('App\Booking');
    }
    public function users()
    {
        return $this->belongsToMany('App\User');
    }

    public function orders(){
        return $this->hasMany('App\Order');
    }


}
