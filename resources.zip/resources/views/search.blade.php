
{{-- This page is for showing all events  --}}
@extends('master')
@section('SearchResult')
        <!-- Page Title
		============================================= -->
<section id="page-title">

    <div class="container clearfix">
        <h1>Search Results</h1>
        <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li class="active">Search</li>
        </ol>
    </div>

</section><!-- #page-title end -->


@endsection