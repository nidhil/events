<section id="slider" class="slider-parallax full-screen dark" >

    <div class="slider-parallax-inner">

        <div class="container clearfix vertical-middle" style="z-index: 3;">

            <div class="heading-block title-center nobottomborder">
                <h1>The Apple WWDC Event starts in:</h1>
            </div>

            <div id="countdown-ex1" class="countdown countdown-large coming-soon divcenter bottommargin" style="max-width:700px;"></div>


            <div class="center topmargin-lg">

                <a href="#" class="button button-3d button-purple button-rounded button-xlarge">Buy Tickets</a>
                <span class="hidden-xs"> - OR - </span>
                <a href="#" class="button button-3d button-white button-light button-rounded button-xlarge">Read Details</a>

            </div>

        </div>

    </div>

</section>