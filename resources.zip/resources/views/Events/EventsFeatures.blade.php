
{{-- This page is for showing events features for home page --}}

    <div class="container clearfix">

        <div class="col_one_fourth nobottommargin">
            <div class="feature-box fbox-effect fbox-center fbox-outline fbox-dark nobottomborder">
                <div class="fbox-icon">
                    <a href="#"><i class="icon-calendar i-alt"></i></a>
                </div>
                <h3>Interactive Sessions<span class="subtitle">Lorem ipsum dolor sit</span></h3>
            </div>
        </div>

        <div class="col_one_fourth nobottommargin">
            <div class="feature-box fbox-effect fbox-center fbox-outline fbox-dark nobottomborder">
                <div class="fbox-icon">
                    <a href="#"><i class="icon-map i-alt"></i></a>
                </div>
                <h3>Great Locations<span class="subtitle">Officia ipsam laudantium</span></h3>
            </div>
        </div>

        <div class="col_one_fourth nobottommargin">
            <div class="feature-box fbox-effect fbox-center fbox-outline fbox-dark nobottomborder">
                <div class="fbox-icon">
                    <a href="#"><i class="icon-microphone2 i-alt"></i></a>
                </div>
                <h3>Global Speakers<span class="subtitle">Laudantium cum dignissimos</span></h3>
            </div>
        </div>

        <div class="col_one_fourth nobottommargin col_last">
            <div class="feature-box fbox-effect fbox-center fbox-outline fbox-dark nobottomborder">
                <div class="fbox-icon">
                    <a href="#"><i class="icon-food2 i-alt"></i></a>
                </div>
                <h3>In-between Meals<span class="subtitle">Perferendis accusantium quae</span></h3>
            </div>
        </div>

        <div class="clear"></div>

        <div class="divider divider-short divider-center"><i class="icon-circle-blank"></i></div>




        <div class="clear"></div>

    </div>
